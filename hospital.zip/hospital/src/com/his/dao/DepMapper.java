package com.his.dao;

import java.util.List;
import java.util.Map;

import com.his.entity.Dep;

/**
 * 部门数据访问接口
 * @author 胡炜钰
 *
 */
public interface DepMapper {
	
	/**
	 * 查询部门表里的记录数
	 * @param parameter		可带条件查询
	 * @return	部门里的记录数
	 */
	int queryCount(Map<String, Object> parameter);
	
	
	/**
	 * 查询部门表里的数据
	 * @param parameter		可带条件查询
	 * @return	部门列表
	 */
	List<Dep> queryByPage(Map<String, Object> parameter);
	
	
	/**
	 * 新增部门
	 * @param entity		部门实体类
	 * @return	受影响的行数
	 */
	int add(Dep entity);
}
