package com.his.dao;

import java.util.List;
import java.util.Map;

import com.his.entity.Reg;

/**
 * 挂号数据访问接口
 * @author 胡炜钰
 *
 */
public interface RegMapper {
	
	/**
	 * 查询挂号表里的记录数
	 * @param parameter		可带条件查询
	 * @return	挂号里的记录数
	 */
	int queryCount(Map<String, Object> parameter);
	
	
	/**
	 * 查询挂号表里的数据
	 * @param parameter		可带条件查询
	 * @return	挂号列表
	 */
	List<Reg> queryByPage(Map<String, Object> parameter);
	
	
	/**
	 * 新增挂号
	 * @param entity		挂号实体类
	 * @return	受影响的行数
	 */
	int add(Reg entity);
}
