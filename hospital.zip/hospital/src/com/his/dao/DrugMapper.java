package com.his.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.his.entity.Doc;
import com.his.entity.Drug;

/**
 * 药品数据访问接口
 * @author 胡炜钰
 *
 */
public interface DrugMapper {
	
	/**
	 * 查询药品表里的记录数
	 * @param parameter		可带条件查询
	 * @return	药品里的记录数
	 */
	int queryCount(Map<String,Object> parameter);
	
	/**
	 * 查询药品表里的数据
	 * @param parameter		可带条件查询
	 * @return	药品列表
	 */
	List<Drug> queryByPage(Map<String,Object> parameter);
	
	/**
	 * 新增药品
	 * @param entity		药品实体类
	 * @return	受影响的行数
	 */
	int add(Drug entity);

}
