package com.his.dao;

import java.util.List;
import java.util.Map;

import com.his.entity.Pat;

/**
 * 病人数据访问接口
 * @author 胡炜钰
 *
 */
public interface PatMapper {
	
	/**
	 * 查询病人表里的记录数
	 * @param parameter		可带条件查询
	 * @return	病人里的记录数
	 */
	int queryCount(Map<String, Object> parameter);
	
	
	/**
	 * 查询病人表里的数据
	 * @param parameter		可带条件查询
	 * @return	病人列表
	 */
	List<Pat> queryByPage(Map<String, Object> parameter);
	
	
	/**
	 * 新增病人
	 * @param entity		病人实体类
	 * @return	受影响的行数
	 */
	int add(Pat entity);
}
