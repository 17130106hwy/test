package com.his.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.his.dao.DepMapper;
import com.his.entity.Dep;

@Service("depServiceImpl")
public class DepServiceImpl implements DepService {

	@Autowired
	@Qualifier("depMapper")
	private DepMapper mapper;
	
	@Override
	public int queryCount(Map<String, Object> parameter) {
		return mapper.queryCount(parameter);
	}

	@Override
	public List<Dep> queryByPage(Map<String, Object> parameter) {
		return mapper.queryByPage(parameter);
	}

	@Override
	public int add(Dep entity) {
		System.out.println(entity.getDepname());
		return mapper.add(entity);
	}

	/**
	 * 1、@Transactional注解只能在抛出RuntimeException或者Error时才会触发事务的回滚。
	 * 常见的非RuntimeException是不会触发事务的回滚的，但是我们平时做业务处理时，需要捕获异常。
	 * 所以可以手动抛出RuntimeException异常或者添加rollbackFor = Exception.class(也可以指定相应异常)
	 * 2、在service层showTransactional()方法中捕获异常不会触发事务回滚，所以需要在controller层调用方法时捕获异常。
	 * 3、只有public修饰的方法才能使事务生效。
	 */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void showTransactional() {
		Dep depname = new Dep();
		// 值的长度超过字段长度，所以插入不成功。
		depname.setDepname("一二三四五六七八九十十一十二时三十四十五十六十七十八十九二十二十一二十二二十三二十四二十五二十六");
		mapper.add(depname);
		depname.setDepname("一二三四五六七八九十十一十二时三十四十五十六十七十八十九二十二十一二十二二十三二十四二十五");
		mapper.add(depname);
	}

	




}
