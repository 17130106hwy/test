package com.his.service;

import java.util.List;
import java.util.Map;

import com.his.entity.Dep;


/**
 * 部门业务逻辑接口
 * @author 胡炜钰
 *
 */
public interface DepService {
	
	/**
	 * 查询部门表中的记录数
	 * @param parameter		查询条件
	 * @return	记录数
	 */
	int queryCount(Map<String, Object> parameter);
	
	/**
	 * 查询表中的数据
	 * @param parameter		条件查询
	 * @return	部门列表
	 */
	List<Dep> queryByPage(Map<String, Object> parameter);
	
	/**
	 * 新增部门数据
	 * @param entity		部门实体类
	 * @return	受影响行数
	 */
	int add(Dep entity);
	
	/**
	 * 仅仅展示事务，与需求无关
	 */
	void showTransactional();
}
