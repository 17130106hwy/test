package com.his.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.his.dao.DocMapper;
import com.his.entity.Doc;

@Service("docServiceImpl")
public class DocServiceImpl implements DocService {

	@Autowired
	@Qualifier("docMapper")
	private DocMapper mapper;
	
	@Override
	public int queryCount(Map<String, Object> parameter) {
		return mapper.queryCount(parameter);
	}

	@Override
	public List<Doc> queryByPage(Map<String, Object> parameter) {
		return mapper.queryByPage(parameter);
	}

	@Override
	public int add(Doc entity) {
		return mapper.add(entity);
	}

	@Override
	public Doc queryDocByDocUser(String parameter) {
		return mapper.queryDocByDocUser(parameter);
	}


}
