package com.his.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.his.entity.Doc;

public interface DocService {
	
	int queryCount(Map<String,Object> parameter);
	
	List<Doc> queryByPage(Map<String,Object> parameter);
	
	int add(Doc entity);
	
	Doc queryDocByDocUser(@Param("docuser") String parameter);

}
