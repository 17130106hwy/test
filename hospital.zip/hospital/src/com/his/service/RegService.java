package com.his.service;

import java.util.List;
import java.util.Map;

import com.his.entity.Reg;


/**
 * 挂号业务逻辑接口
 * @author 胡炜钰
 *
 */
public interface RegService {
	
	/**
	 * 查询挂号表中的记录数
	 * @param parameter		查询条件
	 * @return	记录数
	 */
	int queryCount(Map<String, Object> parameter);
	
	/**
	 * 查询表中的数据
	 * @param parameter		条件查询
	 * @return	挂号列表
	 */
	List<Reg> queryByPage(Map<String, Object> parameter);
	
	/**
	 * 新增挂号数据
	 * @param entity		挂号实体类
	 * @return	受影响行数
	 */
	int add(Reg entity);
}
