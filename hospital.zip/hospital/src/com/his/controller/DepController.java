package com.his.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.his.entity.Dep;
import com.his.service.DepService;

/**
 * 部门控制类
 * @author 胡炜钰
 *
 */
@Controller
@RequestMapping("/dep")
public class DepController {
	
	@Autowired
	@Qualifier("depServiceImpl")
	private DepService depService;
	
	/**
	 * 查询部门列表并跳转部门页面
	 * @param strPageIndex	页码（第几页）
	 * @param strPageSize	每页显示记录数
	 * @param model		用于向页面传参
	 * @return	返回部门列表页面
	 */
	@RequestMapping("/list")
	public String list(String strPageIndex,String strPageSize,Model model) {

		//判断并获取页码，然后传递给页面
		int pageIndex = 1;
		if(strPageIndex != null && strPageSize.matches("\\d+")) {
			pageIndex = Integer.parseInt(strPageIndex);
		}
		model.addAttribute("pageIndex", pageIndex);
		
		//获取并判断每页显示记录数并传递给页面
		int pageSize = 5;
		if(strPageSize != null && strPageSize.matches("\\d+")) {
			pageSize = Integer.parseInt(strPageSize);
		}
		model.addAttribute("pageSize", pageSize);
		
		//获取表中数据量并判断需要生成多少页
		Map<String,Object> parameter = new Hashtable<String, Object>();
		int dataCount = depService.queryCount(parameter);
		int pageCount = 0;
		if (dataCount % pageSize == 0){
			pageCount = dataCount / pageSize;
		}else {
			pageCount = (dataCount / pageSize) + 1;
		}
		model.addAttribute("pageCount", pageCount);
		
		//根据页数循环遍历页码传递给页面
		List<String> listStringPage = new ArrayList<String>();
		for (int i = 1;i <= pageCount; i ++) {
			listStringPage.add(String.valueOf(i));
		}
		model.addAttribute("listStringPage", listStringPage);
		
		//根据页码和每页显示记录数计算偏移量，并分页查询部门数据
		int startIndex = (pageIndex - 1) * pageSize;
		Map<String, Object> mapParameter = new HashMap<String, Object>();
		mapParameter.put("startIndex", startIndex);
		mapParameter.put("pageSize", pageSize);
		List<Dep> list = depService.queryByPage(mapParameter);
		model.addAttribute("list", list);
		
		//跳转部门列表页面
		return "Dep";
	}
	
	/**
	 * 新增部门数据
	 * @param depname		部门实体类
	 * @return	重定向到部门列表方法
	 */
	@RequestMapping("/add")
	public String add(Dep depname) {
		//新增部门数据
		depService.add(depname);
		//重定向到部门列表方法
		return "redirect:/dep/list";
	}
	
	/**
	 * 此方法用于展示事务，与需求无关
	 */
	@ResponseBody
	@RequestMapping("/st")
	public void showTransactional() {
		try {
			depService.showTransactional();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
