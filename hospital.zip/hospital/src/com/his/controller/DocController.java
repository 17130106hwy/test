package com.his.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.his.entity.Dep;
import com.his.entity.Doc;
import com.his.service.DepService;
import com.his.service.DocService;
import com.his.tool.PageTool;

/**
 * 医生控制类
 * @author 胡炜钰
 *
 */
@Controller
@RequestMapping("/doc")
public class DocController {

	@Autowired
	@Qualifier("docServiceImpl")
	private DocService docService;

	@Autowired
	@Qualifier("depServiceImpl")
	private DepService depService;

	/**
	 * 医生登录
	 * @param docuser	医生用户名
	 * @param docpwd	医生密码
	 * @param model		用于向叶面传递参数
	 * @param session	保存医生登录信息
	 * @return		返回相应登录界面
	 */
	@RequestMapping("/login")
	public String login(String docuser, String docpwd, Model model, HttpSession session) {
		if (docuser != null && docuser.length() > 0 && docpwd != null && docpwd.length() > 0) {
			Doc doc = docService.queryDocByDocUser(docuser);
			if (doc == null || !docpwd.equals(doc.getDocpwd())) {
				model.addAttribute("msg", "1");
			} else {
				session.setAttribute("loginDoc", doc);
				if (doc.getDepname().getDepid() == 13) {
					return "redirect:/dep/list";
				} else if (doc.getDepname().getDepid() == 2) {
					return "redirect:/drug/list";
				} else {
					return "redirect:/reg/list1";
				}
			}

		} else {
			model.addAttribute("msg", "0");
		}
		return "login";// 返回到登录界面
	}

	/**
	 * 医生退出登录
	 * @param session
	 * @return	返回登陆界面
	 */
	@RequestMapping("/loginout")
	public String loginout(HttpSession session) {
		session.removeAttribute("loginDoc");
		return "redirect:login";// 重定向-->返回到登陆界面
	}

	/**
	 * 检查医生登录
	 * @param docuser
	 * @param response
	 */
	@ResponseBody
	@RequestMapping("/checkDocUser")
	public void checkDocUser(String docuser, HttpServletResponse response) {
		try {
			if (docuser != null && docuser.length() > 0) {
				Doc doc = docService.queryDocByDocUser(docuser);
				if (doc == null) {
					response.getWriter().print(false);
				} else {
					response.getWriter().print(true);
				}
			} else {
				response.getWriter().print("error");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 查询医生列表并跳转医生页面
	 * @param strPageIndex	页码（第几页）
	 * @param strPageSize	每页显示记录数
	 * @param model		用于向页面传参
	 * @return	返回医生列表
	 */
	@RequestMapping("/list")
	public String list(String strPageIndex, String strPageSize, Model model) {
		int pageIndex = PageTool.getPageIndex(strPageIndex, model);
		int pageSize = PageTool.getPageSize(strPageSize, model);
		Map<String, Object> parameter = new HashMap<String, Object>();
		int dataCount = docService.queryCount(parameter);
		System.out.println("--------->dataCount:"+dataCount+"<---------");
		PageTool.setPageCount(pageSize, dataCount, model);
		Map<String, Object> mapParameter = new HashMap<String, Object>();
		List<Dep> listDept = depService.queryByPage(mapParameter);
		model.addAttribute("listDept", listDept);
		PageTool.setStartIndex(pageSize, pageIndex, mapParameter);
		List<Doc> listDoct = docService.queryByPage(mapParameter);
		model.addAttribute("listDoct", listDoct);
		return "Doc";
	}

	@RequestMapping("/add")
	public String add(Doc parameter) {
		docService.add(parameter);
		return "redirect:/doc/list";
	}

}
