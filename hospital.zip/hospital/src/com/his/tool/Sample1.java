package com.his.tool;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Sample1 {
	
	public static void main() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
		Date date = new Date ();
		String strDate = sdf.format(date);
		System.out.println(strDate);
		// 2021-01-06 
	}

}
