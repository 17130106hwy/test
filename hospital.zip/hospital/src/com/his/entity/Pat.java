package com.his.entity;

import java.io.Serializable;

public class Pat implements Serializable {

	
	private Integer patid;
	
	private String patname;
	
	private String patsex;
	
	private Integer patage;
	
	private String patuser;
	
	private String patpwd;

	public Integer getPatid() {
		return patid;
	}

	public void setPatid(Integer patid) {
		this.patid = patid;
	}

	public String getPatname() {
		return patname;
	}

	public void setPatname(String patname) {
		this.patname = patname;
	}

	public String getPatsex() {
		return patsex;
	}

	public void setPatsex(String patsex) {
		this.patsex = patsex;
	}

	public Integer getPatage() {
		return patage;
	}

	public void setPatage(Integer patage) {
		this.patage = patage;
	}

	public String getPatuser() {
		return patuser;
	}

	public void setPatuser(String patuser) {
		this.patuser = patuser;
	}

	public String getPatpwd() {
		return patpwd;
	}

	public void setPatpwd(String patpwd) {
		this.patpwd = patpwd;
	}
}
