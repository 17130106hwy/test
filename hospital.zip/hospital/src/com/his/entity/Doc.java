package com.his.entity;

import java.io.Serializable;


/**
 * 医生实体类
 * @author 胡炜钰
 *
 */
public class Doc implements Serializable {

	private Integer docid;

	private String docname;

	private Dep depname;

	private String docuser;

	private String docpwd;

	private Integer docprice;

	public Integer getDocid() {
		return docid;
	}

	public void setDocid(Integer docid) {
		this.docid = docid;
	}

	public String getDocname() {
		return docname;
	}

	public void setDocname(String docname) {
		this.docname = docname;
	}

	public Dep getDepname() {
		return depname;
	}

	public void setDepname(Dep depname) {
		this.depname = depname;
	}

	public String getDocuser() {
		return docuser;
	}

	public void setDocuser(String docuser) {
		this.docuser = docuser;
	}

	public String getDocpwd() {
		return docpwd;
	}

	public void setDocpwd(String docpwd) {
		this.docpwd = docpwd;
	}

	public Integer getDocprice() {
		return docprice;
	}

	public void setDocprice(Integer docprice) {
		this.docprice = docprice;
	}
}
