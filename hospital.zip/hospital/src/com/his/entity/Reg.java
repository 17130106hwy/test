package com.his.entity;

import java.io.Serializable;

public class Reg implements Serializable {

	
	private Integer regid;
	
	private Pat patid;
	
	private Doc docid;
	
	private String reginf;
	
	private Integer regprice;

	public Integer getRegid() {
		return regid;
	}

	public void setRegid(Integer regid) {
		this.regid = regid;
	}

	public Pat getPatid() {
		return patid;
	}

	public void setPatid(Pat patid) {
		this.patid = patid;
	}

	public Doc getDocid() {
		return docid;
	}

	public void setDocid(Doc docid) {
		this.docid = docid;
	}

	public String getReginf() {
		return reginf;
	}

	public void setReginf(String reginf) {
		this.reginf = reginf;
	}

	public Integer getRegprice() {
		return regprice;
	}

	public void setRegprice(Integer regprice) {
		this.regprice = regprice;
	}
}
