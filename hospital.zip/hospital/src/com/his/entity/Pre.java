package com.his.entity;

import java.io.Serializable;

public class Pre implements Serializable {

	private Integer preid;
	
	private Reg regid;
	
	private Drug drugid;
	
	private Integer count;
	
	private Integer totprice;

	public Integer getPreid() {
		return preid;
	}

	public void setPreid(Integer preid) {
		this.preid = preid;
	}

	public Reg getRegid() {
		return regid;
	}

	public void setRegid(Reg regid) {
		this.regid = regid;
	}

	public Drug getDrugid() {
		return drugid;
	}

	public void setDrugid(Drug drugid) {
		this.drugid = drugid;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Integer getTotprice() {
		return totprice;
	}

	public void setTotprice(Integer totprice) {
		this.totprice = totprice;
	}
}
