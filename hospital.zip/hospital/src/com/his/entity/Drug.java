package com.his.entity;

import java.io.Serializable;

public class Drug implements Serializable {

	
	private Integer drugid;
	
	private String drugname;
	
	private Integer drugprice;
	
	private Integer drugcount;

	public Integer getDrugid() {
		return drugid;
	}

	public void setDrugid(Integer drugid) {
		this.drugid = drugid;
	}

	public String getDrugname() {
		return drugname;
	}

	public void setDrugname(String drugname) {
		this.drugname = drugname;
	}

	public Integer getDrugprice() {
		return drugprice;
	}

	public void setDrugprice(Integer drugprice) {
		this.drugprice = drugprice;
	}

	public Integer getDrugcount() {
		return drugcount;
	}

	public void setDrugcount(Integer drugcount) {
		this.drugcount = drugcount;
	}
}
