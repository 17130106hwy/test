package com.his.entity;

import java.io.Serializable;

/**
 * 部门实体类
 * @author 胡炜钰
 *
 */
public class Dep implements Serializable {

	//部门ID
	private Integer depid;
	
	//部门名称
	private String depname;

	public Integer getDepid() {
		return depid;
	}

	public void setDepid(Integer depid) {
		this.depid = depid;
	}

	public String getDepname() {
		return depname;
	}

	public void setDepname(String depname) {
		this.depname = depname;
	}
}
